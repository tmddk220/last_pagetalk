package com.bokchi.mysolelife.contentsList

data class ContentModel (
    var title: String = "",
    var imageUrl : String = "",
    var webUrl : String = ""
)